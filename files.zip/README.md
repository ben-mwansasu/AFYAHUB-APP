# Webhook App — WhatsApp / Messenger / Instagram

Server rahisi ya Node.js + Express inayoshughulikia webhook ya Meta (WhatsApp Business, Facebook Messenger, na Instagram).

## Hatua 1: Pandisha code kwenye GitHub

1. Fungua [github.com](https://github.com) na tengeneza repository mpya (mfano: `meta-webhook-app`).
2. Pakia faili hizi zote (`index.js`, `package.json`, `.gitignore`) kwenye repo hiyo.
   - Unaweza kuvuta faili moja kwa moja kwenye GitHub (drag & drop) kupitia "Add file" → "Upload files", au kutumia `git push` kama unafahamu git.

## Hatua 2: Deploy kwenye Render

1. Fungua [render.com](https://render.com) na ufanye akaunti (bure).
2. Bonyeza **New** → **Web Service**.
3. Unganisha GitHub account yako, chagua repo `meta-webhook-app`.
4. Render itagundua kiotomatiki ni Node app. Weka:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Chini kwenye **Environment Variables**, ongeza:
   - `VERIFY_TOKEN` = chagua neno lolote la siri (mfano: `afyahub2026`)
6. Bonyeza **Create Web Service**. Render itajenga na kuanzisha server — subiri dakika 1-2.
7. Baada ya kukamilika, utapata URL kama:
   ```
   https://meta-webhook-app.onrender.com
   ```

## Hatua 3: Jaribu server yako

Fungua kwenye browser: `https://meta-webhook-app.onrender.com/`
Unatakiwa kuona: `Webhook server inafanya kazi ✅`

## Hatua 4: Weka kwenye Meta for Developers

Kwenye ukurasa ule wa "Configuration" ulioniletea picha yake:

- **Callback URL:** `https://meta-webhook-app.onrender.com/webhook`
- **Verify token:** neno lile ulilolitumia kwenye `VERIFY_TOKEN` (mfano: `afyahub2026`) — lazima lifanane kabisa.

Bonyeza **Verify and save**. Kama kila kitu ni sahihi, Meta itaonyesha imethibitishwa (hakuna error).

## Hatua 5: Subscribe kwenye webhook fields

Baada ya verification kufanikiwa, bado utahitaji ku-"subscribe" kwenye fields maalum (mfano `messages` kwa WhatsApp, `messages`/`messaging_postbacks` kwa Messenger). Hii inafanyika kwenye sehemu ya chini ya ukurasa huo huo wa Configuration — kuna orodha ya fields na "Subscribe" button kando ya kila moja.

## Muhimu

- **Render free tier** "inalala" (sleeps) baada ya muda wa kutokutumika, na inachukua sekunde kadhaa kuamka tena. Kwa production ya kweli (timu inayotumia kila siku), fikiria kupandisha kwenye paid plan ili isilale.
- Logs za ujumbe unaopokelewa zinaonekana kwenye Render dashboard chini ya "Logs" — hapo ndipo utaona print za `console.log` wakati mteja anapotuma ujumbe.
- Code ya sasa inaprint tu ujumbe kwenye console. Logic ya kujibu wateja, kuhifadhi database, n.k. inahitaji kuongezwa kwenye `handleWhatsAppMessage` na `handleMetaMessage` functions ndani ya `index.js`.
